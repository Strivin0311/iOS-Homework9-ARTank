//
//  ViewController.swift
//  Tank
//
//  Created by strivin on 2020/12/21.
//

import UIKit
import RealityKit

class ViewController: UIViewController {
    
    
    @IBOutlet var arView: ARView!
    @IBOutlet var MotionButtons: [UIButton]!
    
    var tankAnchor: TinyToyTank._TinyToyTank?
    
    var isActionPlaying: Bool = false // 防止多次动画效果同时触发
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tankAnchor = try! TinyToyTank.load_TinyToyTank()
        arView.scene.anchors.append(tankAnchor!)
        
        tankAnchor!.cannon?.setParent( // 让炮台随着坦克移动
          tankAnchor!.tank, preservingWorldTransform: true)
        
        tankAnchor?.actions.actionComplete.onAction = { _ in
          self.isActionPlaying = false
        }
    }
    
    
    @IBAction func motionButtonTapped(_ sender: UIButton) {
        if self.isActionPlaying { return }
        else { self.isActionPlaying = true }
        
        if sender.title(for: .normal) == "TankRight"{ // 坦克右转
            tankAnchor!.notifications.tankRight.post()

        }
        else if sender.title(for: .normal) == "TankLeft"{ // 坦克左转
            tankAnchor!.notifications.tankLeft.post()
        }
        else if sender.title(for: .normal) == "TankForward"{ // 坦克前进
            tankAnchor!.notifications.tankForward.post()
        }
        else if sender.title(for: .normal) == "TurretLeft"{ // 炮台左转
            tankAnchor!.notifications.turretLeft.post()

        }
        else if sender.title(for: .normal) == "TurretRight"{ // 炮台右转
            tankAnchor!.notifications.turretRight.post()

        }
        else if sender.title(for: .normal) == "CannonFire"{ // 炮台开炮
            tankAnchor!.notifications.cannonFire.post()
        }
    }
    
}
